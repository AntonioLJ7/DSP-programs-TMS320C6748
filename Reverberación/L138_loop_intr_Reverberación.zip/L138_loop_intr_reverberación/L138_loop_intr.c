#include "L138_LCDK_aic3106_init.h"
#include <string.h>
#include <stdint.h>

int T1, T2, T3;
int P1, P2, P3; //Posiciones del buffer en las diferentes lineas
float G;

int16_t buffer1[1600];
int16_t buffer2[3200];
int16_t buffer3[1600];

int16_t linea1=0;
int16_t linea2=0;
int16_t linea3=0;

int32_t sal = 0;
int16_t ent = 0;

uint8_t switches;

//no of new samples in buffer

interrupt void interrupt4(void)  // interrupt service routine
{

    ent = input_left_sample();

    switches = (~read_LCDK_user_DIP()) & 0xF;

    if (switches & 0x1) {
        G = 0.857;
        T1 = 1600;
        T2 = 3200;
        T3 = 1600;
    } else if (switches & 0x2) {

        G = 0.63;
        T1 = 1280;
        T2 = 2560;
        T3 = 1600;
    } else if (switches & 0x4) {

        G = 0.825;
        T1 = 800;
        T2 = 1600;
        T3 = 1600;
    } else if (switches & 0x8) {

        G = 0.42;
        T1 = 640;
        T2 = 1280;
        T3 = 1600;

    }else{

        output_left_sample(ent);
        return;
    }

    buffer1[P1] = ent * G;
    buffer2[P2] = ent;
    buffer3[P3] = linea3 * G;

    linea1 = ent;
    linea2 = buffer1[P1];
    linea3 = buffer2[P2] + buffer3[P3];

    P1 = (P1 + 1) % T1;
    P2 = (P2 + 1) % T2;
    P3 = (P3 + 1) % T3;

    sal = linea1 + linea2 + linea3;

    if (sal > INT16_MAX)
        sal = INT16_MAX;

    if (sal < INT16_MIN)
        sal = INT16_MIN;

    output_left_sample(sal);

    return;
}

//Funci�n principal
int main(void) {

    L138_initialise_intr(FS_32000_HZ,ADC_GAIN_0DB,DAC_ATTEN_0DB,LCDK_LINE_INPUT);

    while (1){
        switches = (~read_LCDK_user_DIP()) & 0xF;
    }
}
