// L138_loop_intr.c
//

#include "L138_LCDK_aic3106_init.h"
#include "math.h"

#define BUFFER_SIZE 8000
#pragma DATA_SECTION(buffer, ".EXT_RAM")

uint8_t read_LCDK_user_DIP();
uint8_t user = 0;

#define SAMP_FREC 8000 // Frecuencia de muestreo
#define PI 3.141592
float frecuencia = 250.0; // Frecuencia del seno a generar
float amplitud = 20000.0; // Amplitud de la se�al
float theta = 0.0; // Valor entre -2*PI y 2*PI
float theta_inc; // Incrementos de la se�al de salida

int16_t g = 0,g_salida;

//int16_t amplitud = 20000;
int16_t amplitud_salida = 0;
int16_t buffer[BUFFER_SIZE];
int16_t posBuffer = 0;

int cuenta = 0;

void vaciar_buffer(){
    int i=0;

    for(i=0;i<BUFFER_SIZE;i++){

        buffer[i] = 0;

    }
}

interrupt void interrupt4(void)
{

    while(1){

        theta_inc = 2*PI*frecuencia/SAMP_FREC;
        theta += theta_inc;
        if (theta > 2*PI) theta -= 2*PI;
        g = (int16_t) amplitud*sin(theta);


        buffer[posBuffer] = g;
        posBuffer = (posBuffer + 1) % BUFFER_SIZE; // Se avanza una posici�n en el
        g_salida = buffer[posBuffer]; // Se toma la muestra m�s antigua

        user = ~read_LCDK_user_DIP();

        switch(user){
            case 0xf1:
                frecuencia = 500.0;
                break;

            case 0xf2:
                frecuencia = 750.0;
                break;

            case 0xf4:
                frecuencia = 1500.0;
                break;

            case 0xf8:
                 frecuencia = 2000.0;
                 break;
        }

        output_left_sample((int16_t) amplitud*sin(theta));

//
//        cuenta++;
//
//        if (cuenta <= 4){
//
//            buffer[posBuffer] = amplitud;
//            posBuffer = (posBuffer + 1) % BUFFER_SIZE; // Se avanza una posici�n en el
//            amplitud_salida = buffer[posBuffer]; // Se toma la muestra m�s antigua
//
//            output_sample(amplitud_salida);
//        }
//
//        if(cuenta > 4){
//
//            buffer[posBuffer] = amplitud;
//            posBuffer = (posBuffer + 1) % BUFFER_SIZE; // Se avanza una posici�n en el
//            amplitud_salida = buffer[posBuffer]; // Se toma la muestra m�s antigua
//
//            output_sample(amplitud_salida);
//        }
//
//        if(cuenta == 4){
//            amplitud = (-1)*amplitud;
//        }
//
//        if(cuenta == 8){
//            amplitud = (-1)*amplitud;
//            cuenta = 0;
//        }

    }

return;
}


int main(void)
{
  vaciar_buffer();
  L138_initialise_intr(FS_8000_HZ,ADC_GAIN_0DB,DAC_ATTEN_0DB,LCDK_LINE_INPUT);

  while(1);
}
