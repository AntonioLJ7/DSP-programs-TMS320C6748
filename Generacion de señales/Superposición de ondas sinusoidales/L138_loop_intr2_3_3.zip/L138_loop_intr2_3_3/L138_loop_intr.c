// L138_loop_intr.c
//

#include "L138_LCDK_aic3106_init.h"
#include "math.h"
#include <stdint.h>

//buffer
#define BUFFER_SIZE 8000
#pragma DATA_SECTION(buffer, ".EXT_RAM")

int32_t buffer[BUFFER_SIZE];
int16_t posBuffer = 0;
int cuenta = 0;
int32_t salida_buffer;

//
#define SAMP_FREC 8000 // Frecuencia de muestreo
#define PI 3.141592
float frecuencia[5] = {250.0,500.0,750.0,1500.0,2000.0}; // Frecuencia del seno a generar
float amplitud = 20000; // Amplitud de la se�al
float theta[5] = {0.0,0.0,0.0,0.0,0.0}; // Valor entre -2*PI y 2*PI
float theta_inc[5]; // Incrementos de la se�al de salida
uint8_t bits[5] = {0xf,0x1,0x2,0x4,0x8};

uint8_t read_LCDK_user_DIP();
uint8_t switches = 0;



void vaciar_buffer(){
    int i=0;
    for(i=0;i<BUFFER_SIZE;i++){
        buffer[i] = 0;
    }
}

interrupt void interrupt4(void)
{

       float salida = 0;

       switches = (~read_LCDK_user_DIP() & bits[0]);

       if (switches & bits[1]) { // switch 5

           theta[1] += theta_inc[1];

               if (theta[1] > 2 * PI)
                   theta[1] = -2 * PI;
               salida += (int16_t) amplitud * sin(theta[1]);

           }

           if (switches & bits[2]) {  // switch 6

               theta[2] += theta_inc[2];

               if (theta[2] > 2 * PI)
                   theta[2] = -2 * PI;

               salida += (int16_t) amplitud * sin(theta[2]);
           }

           if (switches & bits[3]) { // switch 7

               theta[3] += theta_inc[3];

               if (theta[3] > 2 * PI)
                   theta[3] = -2 * PI;

               salida += (int16_t) amplitud * sin(theta[3]);
           }

           if (switches & bits[4]) { // switch 8

               theta[4] += theta_inc[4];

               if (theta[4] > 2 * PI)
                   theta[4] = -2 * PI;

               salida += (int16_t) amplitud * sin(theta[4]);

           }else{  //Ning�n switch

               theta[0] += theta_inc[0];

               if (theta[0] > 2 * PI)
                   theta[0] = -2 * PI;

           }


//        cuenta++;
//
//        if (cuenta <= 4){
//
//               buffer[posBuffer] = salida;
//               posBuffer = (posBuffer + 1) % BUFFER_SIZE; // Se avanza una posici�n en el
//               salida_buffer = buffer[posBuffer]; // Se toma la muestra m�s antigua
//
//       }
//
//        if(cuenta > 4){
//
//            buffer[posBuffer] = salida;
//            posBuffer = (posBuffer + 1) % BUFFER_SIZE; // Se avanza una posici�n en el
//            salida_buffer = buffer[posBuffer]; // Se toma la muestra m�s antigua
//
//        }
//
//       if(cuenta == 4){
//          // amplitud = (-1)*amplitud;
//       }
//
//        if(cuenta == 8){
//            //amplitud = (-1)*amplitud;
//           cuenta = 0;
//        }

        //Saturaci�n si sobrepasa del m�ximo o m�nimo
        if (salida > INT16_MAX) //Si supera el valor maximo
            salida = INT16_MAX;
        if (salida < INT16_MIN) //Si supera el valor minimo
            salida = INT16_MIN;

        output_left_sample((int32_t) salida); //Muestra de entrada con solo un canal

        return;
}


int main(void)
{
  vaciar_buffer();

  for(i=0;i<5;i++){
      theta_inc[i] = 2*PI*frecuencia[i]/SAMP_FREC;
  }

  L138_initialise_intr(SAMP_FREC,ADC_GAIN_0DB,DAC_ATTEN_0DB,LCDK_LINE_INPUT);

while(1);
}
