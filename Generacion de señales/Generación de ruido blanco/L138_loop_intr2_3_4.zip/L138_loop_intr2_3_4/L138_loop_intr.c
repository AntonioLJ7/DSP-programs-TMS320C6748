// L138_loop_intr.c
//

#include "L138_LCDK_aic3106_init.h"
#include "math.h"

//#pragma DATA_SECTION(buffer, ".EXT_RAM")

#define BUFFER_SIZE 512
#define K 12
#define desviacion 800
#define mediana 0

int32_t x[K];
float X[K];
float Y;

float buffer1[BUFFER_SIZE];
int16_t buffer2[BUFFER_SIZE];
int16_t pos_buffer = 0;

int16_t salida = 0;

interrupt void interrupt4(void)
{
    int i=0;

    for(i=0;i<K;i++){

       X[i+1] = 65539 * ((i+1) % (K));
       X[i] = X[i+1] * 4.65661287524797e-10;

       buffer1[i] = X[i];
    }



    for(i=0;i<K;i++){
        Y +=X[i];
    }

    Y -= (float)K/2.0;

    Y /= sqrt(K/12.0);

    Y = Y*desviacion + mediana;

    salida = (int16_t)(Y);

    output_right_sample(salida);

    buffer2[pos_buffer] = salida;
    pos_buffer = (pos_buffer+1) % BUFFER_SIZE;


    return;
}


int main(void)
{
  X[0] = 3;
  L138_initialise_intr(FS_8000_HZ,ADC_GAIN_0DB,DAC_ATTEN_0DB,LCDK_LINE_INPUT);

  while(1);
}
