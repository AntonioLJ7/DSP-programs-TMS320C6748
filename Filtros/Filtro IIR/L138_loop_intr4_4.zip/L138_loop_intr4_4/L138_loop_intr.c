// L138_iirsostr_intr.c
//
// IIR filter implemented using second order sections
// floating point coefficients read from file
//

#include "L138_LCDK_aic3106_init.h"

//Ejemplo
//#define NUM_SECTIONS 4
//
//float b[NUM_SECTIONS][3] = {
//{1.91736185E-01, -3.79642654E-01, 1.91736185E-01},
//{4.18315795E-01, -8.25760832E-01, 4.18315795E-01},
//{7.63646097E-02, -1.47756602E-01, 7.63646097E-02},
//{5.80229995E-02, 5.80229995E-02, 0.00000000E+00} };
//
//float a[NUM_SECTIONS][3] = {
//{1.00000000E+00, -1.98067618E+00, 9.94469136E-01},
//{1.00000000E+00, -1.96778344E+00, 9.78654195E-01},
//{1.00000000E+00, -1.94813060E+00, 9.53103216E-01},
//{1.00000000E+00, -9.67778981E-01, 0.00000000E+00} };

//PASO BAJO
//#define NUM_SECTIONS 3
//
//float b[NUM_SECTIONS][3] = {
//{3.56574350E-01, -6.57756936E-01, 3.56574350E-01},
//{1.83090440E-01, -2.11416067E-01, 1.83090440E-01},
//{5.88561449E-03, -1.12149398E-02, 5.88561449E-03} };
//
//float a[NUM_SECTIONS][3] = {
//{1.00000000E+00, -1.91719042E+00, 9.40883665E-01},
//{1.00000000E+00, -1.89712792E+00, 9.03090062E-01},
//{1.00000000E+00, -1.94392378E+00, 9.81802119E-01} };

//Paso Alto
#define NUM_SECTIONS 3

float b[NUM_SECTIONS][3] = {
{2.84542744E-01, -5.62489757E-01, 2.84542744E-01},
{7.76570940E-01, -1.54589977E+00, 7.76570940E-01},
{1.99032975E+00, -1.99032975E+00, 0.00000000E+00} };

float a[NUM_SECTIONS][3] = {
{1.00000000E+00, -1.78964976E+00, 9.38561407E-01},
{1.00000000E+00, -1.41485099E+00, 6.84190658E-01},
{1.00000000E+00, -2.08197593E-01, 0.00000000E+00} };


float w[NUM_SECTIONS][2] = {0};

uint8_t switches;

interrupt void interrupt4(void) // associated in intvecs.asm with INT4
{
    int section;   // index for section number
    float input;   // input to each section
    float wn,yn;   // intermediate and output values in each stage

    switches = ~read_LCDK_user_DIP();

     input = ((float)input_left_sample());
     for (section=0 ; section< NUM_SECTIONS ; section++)
     {
       wn = input - a[section][1]*w[section][0]
            - a[section][2]*w[section][1];
       yn = b[section][0]*wn + b[section][1]*w[section][0]
            + b[section][2]*w[section][1];
       w[section][1] = w[section][0];
       w[section][0] = wn;
       input = yn;              // output of current section will be input to next
     }
     //output_left_sample((int16_t)(yn)); // before writing to codec

     if (switches & 0x01)
        output_left_sample((int16_t)(yn)); // before writing to codec
     else
        output_left_sample((int16_t)input);
     return;
}

int main(void)
{

  L138_initialise_intr(FS_32000_HZ,ADC_GAIN_0DB,DAC_ATTEN_0DB,LCDK_LINE_INPUT);

  while(1);

}
