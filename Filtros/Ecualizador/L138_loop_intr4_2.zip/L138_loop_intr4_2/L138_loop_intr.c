// L138_loop_intr.c
//
#define BL 91
#include "L138_LCDK_aic3106_init.h"
#include "fdacoefs_bajo.h"
#include "fdacoefs_alto.h"
float x[BL];

interrupt void interrupt4(void)  // interrupt service routine
{

    if (read_LCDK_user_DIP() & 0x1) {
        output_left_sample(input_left_sample());
        return;
    }

    float resultado = 0;
    int i = 0;

    x[0] = input_left_sample();


    resultado = h[0] * x[0];

    for (i = BL - 1; i > 0; i--) {
        resultado += h[i] * x[i];
        x[i] = x[i - 1];
    }

    output_left_sample(resultado);

  return;
}

int main(void)
{
  L138_initialise_intr(FS_32000_HZ,ADC_GAIN_0DB,DAC_ATTEN_0DB,LCDK_LINE_INPUT);
  while(1);
}
