// L138_loop_intr.c
//
#define BL 91
#include "L138_LCDK_aic3106_init.h"
#include "fdacoefs.h"
#include "stdint.h"
float x[BL];


interrupt void interrupt4(void)  // interrupt service routine
{

    if (read_LCDK_user_DIP() & 0x1) {
        output_left_sample(input_left_sample());
        return;
    }

    float y=0.0;
    int i = 0;

    x[0] = input_left_sample();


    y= h[0] * x[0];
    for (i = BL - 1; i > 0; i--) {
        y += h[i] * x[i];
        x[i] = x[i - 1];
    }

   if (y > INT16_MAX)
       y = INT16_MAX;
   if (y < INT16_MIN)
       y = INT16_MIN;

    output_left_sample(y);

  return;
}

int main(void)
{
  L138_initialise_intr(FS_32000_HZ,ADC_GAIN_0DB,DAC_ATTEN_0DB,LCDK_LINE_INPUT);
  while(1);
}
