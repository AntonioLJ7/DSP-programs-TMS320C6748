// L138_loop_intr.c
//

#include "L138_LCDK_aic3106_init.h"

#define BUFFER_SIZE 4000
#pragma DATA_SECTION(buffer, ".EXT_RAM")

uint32_t sampleIn, sampleOut;
uint32_t buffer[BUFFER_SIZE];
uint16_t posBuffer = 0;

void vaciar_buffer(){
    int i=0;

    for(i=0;i<BUFFER_SIZE;i++){

        buffer[i] = 0;

    }
}

interrupt void interrupt4(void)
{
    uint32_t salida_muestra;
    int16_t imputIzq,imputDer;
    int32_t outputDer,outputIzq;

    imputDer = input_right_sample();
    outputDer = buffer[posBuffer] + imputDer ; // Muestra completa 32 bits (sin signo)
    buffer[posBuffer] = outputDer >> 1;

    imputIzq = input_left_sample();
    outputIzq = buffer[posBuffer] + imputIzq ; // Muestra completa 32 bits (sin signo)
    buffer[posBuffer] = outputIzq >> 1;

    posBuffer = (posBuffer + 1) % BUFFER_SIZE; // Se avanza una posici�n en el

    salida_muestra = buffer[posBuffer]; // Se toma la muestra m�s antigua

    output_sample(salida_muestra);

return;
}


int main(void)
{
  vaciar_buffer();
  L138_initialise_intr(FS_8000_HZ,ADC_GAIN_0DB,DAC_ATTEN_0DB,LCDK_LINE_INPUT);

  while(1);
}
